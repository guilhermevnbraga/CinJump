Branch criada para testes do codigo de plataforma
