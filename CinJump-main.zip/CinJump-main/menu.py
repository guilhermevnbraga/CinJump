import pygame
import sys
from sprites import *

#aqui temos as variaveis que serão usadas no codigo
pontuacao_recorde = 0 # pontuação maxima atinigida no jogo que ficara salva e aparecera na tela de menu
LARGURA = 600#largura da tela
ALTURA = 800#altura da tela
FPS = 60#fps da tela colocamos 60 já que é o padrão
pygame.init()#começa o pygame
pygame.display.set_caption('Cin Jump')#nome do noso jogo
fonte = pygame.font.SysFont("Comic Sans MS", 20, True, True)#fonte usada no jogo
TELA = pygame.display.set_mode((LARGURA, ALTURA))#sdesenhar tela
clock = pygame.time.Clock()#clock do jogo

#aqui temos a classe do botão que sera usado na interface do jogo
class Button():
	def __init__(self, image, x_pos, y_pos):
		self.image = image #imagem do botao
		self.x_pos = x_pos
		self.y_pos = y_pos
		self.rect = self.image.get_rect(center=(self.x_pos, self.y_pos))

	def update(self): #blit poe uma imagem na tela
		TELA.blit(self.image, self.rect) #usa a posicao do rect para por a imagem na tela

	def clique(self, posicao): #confere se a posicao do mouse = posicao do botao
		if posicao[0] in range(self.rect.left, self.rect.right) and posicao[1] in range(self.rect.top, self.rect.bottom):
			return True
		else:
			return False	

#aqui é a fução que seleciona a mensagem que aparece na tela de gameover ela devolve a mensagem e a posição x da mensagem
def mensagem_gameover(pontuacao):
    if pontuacao <= 5000:
        mensagem = "Reprovado!"
        x = 250
    elif pontuacao <= 10000:
        mensagem = "Ficou na final..."
        x = 200
    elif pontuacao <= 20000:
        mensagem = "DOPE! Mas ainda dá para melhorar"
        x = 105
    elif pontuacao <= 30000:
        mensagem = "CRAZY! Continue pulando!"
        x = 140
    elif pontuacao <= 40000:
        mensagem = "BADASS! Tirou 10 em IP com essa pontuação"
        x = 25
    elif pontuacao <= 50000:
        mensagem = "APOCALYPTIC! Joga muito!"
        x = 140
    elif pontuacao <= 60000:
        mensagem = "SAVAGE! Você ultrapassou César!"
        x = 105
    elif pontuacao <= 70000:
        mensagem = "SICK SKILLS! VOA MULEKE!"
        x = 130
    elif pontuacao >= 70001 and pontuacao < 100000:
        mensagem = "SSSTYLISH! Já pode tirar o diploma!"
        x = 60
    elif pontuacao >= 100000:
        mensagem = "A quanto tempo você está aqui?"
        x = 105
    
    return mensagem, x