from jogo import *
#chama o jogo

if __name__ == "__main__":
    comeco()